import random
class Agent:
  def __init__(self, turn):
    pass

  def choose_action(self, obs):
    return random.randint(0, 7)